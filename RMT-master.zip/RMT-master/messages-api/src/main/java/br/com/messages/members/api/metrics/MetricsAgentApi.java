package br.com.messages.members.api.metrics;

public class MetricsAgentApi {

	public static final String METRICS_PATH = "metrics-agent/rest";

	public static final String ROOT = "/metrics/";

	public static final String PROJECT_PARAM = "/{projectId}/{refactoredProjectId}";
	
	public static final String FORCE_REGISTRATION = "/force-registration";

}
