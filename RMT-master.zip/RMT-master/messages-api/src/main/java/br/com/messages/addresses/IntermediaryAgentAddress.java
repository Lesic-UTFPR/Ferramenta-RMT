package br.com.messages.addresses;

public class IntermediaryAgentAddress {

	public final static String HOST = "localhost";

	public final static String PORT = "8080";

}
