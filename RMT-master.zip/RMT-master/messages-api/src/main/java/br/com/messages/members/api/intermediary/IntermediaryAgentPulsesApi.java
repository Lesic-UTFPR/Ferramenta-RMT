package br.com.messages.members.api.intermediary;

public class IntermediaryAgentPulsesApi {

	public static final String ROOT = "/pulses";

	public static final String TEST = "/test";

	public static final String REGISTRATION = "/register";

	public static final String RENEW = "/renew";

}
