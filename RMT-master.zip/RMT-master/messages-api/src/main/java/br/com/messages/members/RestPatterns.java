package br.com.messages.members;

public class RestPatterns {

	public static final String PRODUCES_JSON = "application/json; charset=UTF-8";

	public static final String CONSUMES_JSON = "application/json";

}
