package br.com.messages.members.api.intermediary;

public class IntermediaryAgentCoreApi {

	public final static String AGENT_PATH = "intermediary-agent/rest";

}
