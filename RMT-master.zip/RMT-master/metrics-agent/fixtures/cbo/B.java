package dit;

public class B extends A {

}
