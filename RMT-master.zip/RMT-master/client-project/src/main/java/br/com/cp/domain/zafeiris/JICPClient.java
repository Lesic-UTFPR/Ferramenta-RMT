package br.com.cp.domain.zafeiris;

public class JICPClient {

	public JICPClient(Protocol protocol, ConnectionFactory connectionFactory, int pOOL_SIZE) {
	}

}
