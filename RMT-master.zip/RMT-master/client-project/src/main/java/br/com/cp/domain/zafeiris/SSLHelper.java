package br.com.cp.domain.zafeiris;

public class SSLHelper {

	public static SSLContext createContext() {
		// TODO Auto-generated method stub
		return null;
	}

	public static boolean needAuth() {
		// TODO Auto-generated method stub
		return true;
	}

}
