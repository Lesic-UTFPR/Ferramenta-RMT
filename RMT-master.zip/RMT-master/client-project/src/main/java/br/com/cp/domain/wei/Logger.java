package br.com.cp.domain.wei;

public interface Logger {
	
	void writeLog();

}
