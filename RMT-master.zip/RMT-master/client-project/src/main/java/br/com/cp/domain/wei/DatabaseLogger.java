package br.com.cp.domain.wei;

public class DatabaseLogger implements Logger{

	@Override
	public void writeLog() {
		
	}

}
