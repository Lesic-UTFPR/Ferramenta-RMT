package br.com.cp.domain.zafeiris;

public class ICPException extends Exception {

}
