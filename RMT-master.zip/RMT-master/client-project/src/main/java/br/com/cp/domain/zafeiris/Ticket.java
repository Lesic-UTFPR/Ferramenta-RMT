package br.com.cp.domain.zafeiris;

public class Ticket {

	public Ticket(int i) {
	}

	public void start() {
	}

}
