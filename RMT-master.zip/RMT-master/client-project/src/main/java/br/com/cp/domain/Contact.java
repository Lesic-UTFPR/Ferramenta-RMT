package br.com.cp.domain;

public interface Contact {

	String display();
}
