package br.com.cp.domain.zafeiris;

public enum Logger {
	FINE
}
