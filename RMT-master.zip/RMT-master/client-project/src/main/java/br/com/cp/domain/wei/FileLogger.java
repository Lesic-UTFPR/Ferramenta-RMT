package br.com.cp.domain.wei;

public class FileLogger implements Logger{

	@Override
	public void writeLog() {
		
	}

}
