package br.com.cp.domain.zafeiris;

public class TransportAddress {

	public TransportAddress(String host, int port) {
		// TODO Auto-generated constructor stub
	}

}
