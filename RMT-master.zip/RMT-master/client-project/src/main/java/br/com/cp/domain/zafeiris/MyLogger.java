package br.com.cp.domain.zafeiris;

public class MyLogger {

	public boolean isLoggable(Logger fine) {
		// TODO Auto-generated method stub
		return false;
	}

	public void log(Logger fine, String string) {
		// TODO Auto-generated method stub
		
	}

}
