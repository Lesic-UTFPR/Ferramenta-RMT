package br.com.cp.domain.zafeiris;

public class Profile {

	public int getparameter(int cONNECTION_TIMEOUT, int i) {
		return i;
	}

}
