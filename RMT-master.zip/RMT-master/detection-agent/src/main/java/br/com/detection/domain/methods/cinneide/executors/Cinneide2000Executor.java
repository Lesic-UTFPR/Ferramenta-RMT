package br.com.detection.domain.methods.cinneide.executors;

import br.com.detection.domain.methods.RefactoringExecutor;

public interface Cinneide2000Executor extends RefactoringExecutor{	

}
