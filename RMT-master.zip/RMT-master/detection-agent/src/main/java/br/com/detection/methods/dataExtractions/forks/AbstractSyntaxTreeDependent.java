package br.com.detection.methods.dataExtractions.forks;

public interface AbstractSyntaxTreeDependent extends DataExtractionDependent {

}
