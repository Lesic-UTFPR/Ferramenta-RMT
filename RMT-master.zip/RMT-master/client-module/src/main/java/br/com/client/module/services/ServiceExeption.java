package br.com.client.module.services;

public class ServiceExeption extends Exception {

	private static final long serialVersionUID = 1L;

	public ServiceExeption(String msg) {
		super(msg);
	}
}
