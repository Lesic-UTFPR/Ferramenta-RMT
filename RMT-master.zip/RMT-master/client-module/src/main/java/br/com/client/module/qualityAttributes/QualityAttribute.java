package br.com.client.module.qualityAttributes;

public enum QualityAttribute {
	MAINTAINABILITY, 
	RELIABILITY, 
	REUSABILITY, 
	USABILITY;
}
