package br.com.intermediary.managers.members.exceptions.pulses;

import br.com.intermediary.managers.projects.exceptions.ManagerException;

public class PulseException extends ManagerException {

	private static final long serialVersionUID = 1L;

	public PulseException(String arg0) {
		super(arg0);
	}

}
