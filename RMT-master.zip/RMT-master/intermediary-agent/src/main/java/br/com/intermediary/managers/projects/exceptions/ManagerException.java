package br.com.intermediary.managers.projects.exceptions;

public class ManagerException extends Exception{

	private static final long serialVersionUID = 1L;

	public ManagerException(String arg0) {
		super(arg0);
	}
	
}
