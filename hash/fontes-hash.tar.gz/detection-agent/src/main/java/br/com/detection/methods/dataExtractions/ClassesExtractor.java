package br.com.detection.methods.dataExtractions;

import java.util.Collection;

public interface ClassesExtractor {
	
	Collection<Class<?>> getAll();
	
}
