package br.com.detection.domain.methods.weiL.executors;

import br.com.detection.domain.methods.RefactoringExecutor;

public interface WeiEtAl2014Executor extends RefactoringExecutor {

}
