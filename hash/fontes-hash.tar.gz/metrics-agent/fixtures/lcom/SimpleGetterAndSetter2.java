package lcom;

public class SimpleGetterAndSetter2 {

	private int f3;
	private int f4;
	
	public int f3() {
		return f3;
	}
	
	public void setf3(int f3) {
		this.f3 = f3;
	}
	
	public int f4() {
		return f4;
	}
	
	public void setf4(int f4) {
		this.f4 = f4;
	}
}
