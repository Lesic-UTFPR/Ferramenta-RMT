package methods;

public class Methods {
	
	private int a() {}
	private String b() {}
	public double c() {}
	private static String d() {}
	public static int e() {}
	
}