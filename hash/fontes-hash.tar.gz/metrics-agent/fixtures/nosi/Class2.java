package nosi;

import java.util.Calendar;

public class Class2 {
	
	public void a() {
		a();
		
		Calendar x = Calendar.getInstance();
	}
}