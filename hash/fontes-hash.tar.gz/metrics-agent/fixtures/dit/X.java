package dit;

public class X extends ZZZ {

}
