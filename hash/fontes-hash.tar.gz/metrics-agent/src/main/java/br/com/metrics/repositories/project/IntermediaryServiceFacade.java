package br.com.metrics.repositories.project;

public interface IntermediaryServiceFacade {

}
